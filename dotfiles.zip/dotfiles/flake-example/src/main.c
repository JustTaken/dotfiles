#include <raylib.h>
#include <stdio.h>

int main() {
  printf("printando\n");
  return 0;
}
